package helper;

// TODO: Auto-generated Javadoc
/**
 * This class adds colors in game.
 * 
 * @author Gargi Sharma
 * @version 1.0.0
 */

public enum Colors {
	
    /** The red. */
	RED,
    /** The pink. */
    PINK,
    /** The white. */
    WHITE,
    /** The yellow. */
    YELLOW,
    /** The green. */
    GREEN,
    /** The blue. */
    BLUE,
    /** The magenta. */
    MAGENTA,
    /** The black. */
    BLACK,
    /** The orange. */
    ORANGE
}





