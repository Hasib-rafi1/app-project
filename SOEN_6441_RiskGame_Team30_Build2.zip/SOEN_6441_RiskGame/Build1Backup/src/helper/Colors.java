package helper;

/**
 * This is used to add colors in game
 * @author Gargi Sharma
 * @version 1.0.0
 */

public enum Colors {
	RED, PINK, WHITE, YELLOW, GREEN, BLUE, MAGENTA, BLACK, ORANGE;
}





