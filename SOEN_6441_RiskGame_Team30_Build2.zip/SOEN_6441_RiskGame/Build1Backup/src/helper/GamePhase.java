package helper;
/**
 * This enum is containging the phases name of the game
 * @author Hasibul Huq
 *
 */
public enum GamePhase {
	Startup, Reinforcement, Attack, Fortification
}
